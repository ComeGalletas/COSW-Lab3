'use strict';

angular.module('clientsDirectory.clientsDirectory', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/clientsDirectory', {
    templateUrl: 'clientsDirectory/clientsDirectory.html',
    controller: 'ClientsDirectoryController'
  });
}])

.controller('ClientsDirectoryController', ['$scope', 'Clients', '$mdDialog', function ($scope, Clients, $mdDialog) {

    $scope.clientsList=Clients.query();

    $scope.key = 'id';
    $scope.reverse = false;

    $scope.status = '  ';
      $scope.customFullscreen = false;

      $scope.showAlert = function(ev, client) {
        $mdDialog.show(
          $mdDialog.alert()
            .parent(angular.element(document.querySelector('#popupContainer')))
            .clickOutsideToClose(true)
            .title("" + client.name + ' Description')
            .textContent(client.profileDescription)
            .ariaLabel('Client Description')
            .ok('Close')
            .targetEvent(ev)
        );
      };

      $scope.showAdvanced = function(ev, client) {
          $mdDialog.show({
            locals: {
                  client: client
            },
            controller: DialogController,
            templateUrl: 'clientsDirectory/dialog1.html',
            parent: angular.element(document.body),
            targetEvent: ev,
            clickOutsideToClose:true,
            fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
          });

          function DialogController($scope, $mdDialog, client){
            $scope.client = client;
            $scope.closeDialog = function(){
                $mdDialog.hide();
            }
          }
      };





}]);
